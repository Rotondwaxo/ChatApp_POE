package com.mycompany.chatapppoe;

/**
 * Login class verifies credentials against stored registration data.
 */
public class Login {
    private String storedUsername;
    private String storedPassword;
    
    public Login(String storedUsername, String storedPassword) {
        this.storedUsername = storedUsername;
        this.storedPassword = storedPassword;
    }
    
    public boolean loginUser(String enteredUsername, String enteredPassword) {
        return storedUsername != null && storedUsername.equals(enteredUsername) &&
               storedPassword != null && storedPassword.equals(enteredPassword);
    }
    
    public String returnLoginStatus(boolean loginSuccess, String firstName, String lastName) {
        if (loginSuccess) {
            return "Welcome " + firstName + " " + lastName + " it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }
}